# ntils:lookups
Lookups is purely a structure file used by other modules. This currently contains lookup tables for `b64` and `uuid`.